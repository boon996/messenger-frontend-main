import axios from 'axios';

export const api = axios.create({
    headers: {
        'Authorization': 'Token ' + localStorage.getItem('token'),
        'Content-Type': 'application/json;charset=utf-8'
    },
    baseURL: 'http://localhost:8080/api/'
});

export function changeToken(token) {
    localStorage.setItem("token", token)
    api.defaults.headers = {
        'Authorization': 'Token ' + token,
        'Content-Type': 'application/json;charset=utf-8'
    }
}

export const authApi = {
    async login(login, password) {
        let response = await api.post('login', {login: login, password: password})
        return (await response.data).Token
    }
};

export const messagesApi = {
    async list(login) {
        let response = await api.get('messages', {params: {login: login}})
        return (await response.data).messages
    },
    async send(to, text) {
        return await api.post('message/send', {'to': to, 'text': text})
    }
}

export const dialogsApi = {
    async list() {
        let response = await api.get('dialogs')
        return (await response.data).dialogs
    },
    async add(login) {
        let response = await api.post('contact/add', {'login': login})
        return response.status
    }
}