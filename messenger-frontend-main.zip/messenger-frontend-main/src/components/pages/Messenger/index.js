import React, {Fragment, useState} from 'react'
import './style.css';
import DialogList from "../../containers/DialogList";
import MessageList from "../../containers/MessageList";

export const Messenger = () => {
    const [currentDialog, setCurrentDialog] = useState(null)

    return (
        <Fragment>
            <div className="messenger">
                <div className="scrollable sidebar">
                    <DialogList currentDialog={currentDialog} setCurrentDialog={setCurrentDialog}/>
                </div>
                <div className="scrollable content">
                    <MessageList currentDialog={currentDialog}/>
                </div>
            </div>
        </Fragment>
    )
};