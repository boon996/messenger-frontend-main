import React, {Fragment, useState} from 'react'
import {authApi, changeToken} from "../../../utils/Api";
import {useAuth} from "../../../context/AuthProvider";
import './style.css';
import {Redirect} from "react-router-dom";

export const Login = (props) => {
    const {isAuth, setIsAuth, setLogin} = useAuth();
    const [currentLogin, setCurrentLogin] = useState("");
    const [password, setPassword] = useState("");

    if (isAuth) {
        return <Redirect to={'/'}/>
    }

    const handleSubmit = async (event) => {
        event.preventDefault();

        try {
            const token = await authApi.login(currentLogin, password)
            changeToken(token)
            setIsAuth(true)
            setLogin(currentLogin)
        } catch (e) {
        }
    };

    const handleChangeLogin = (event) => {
        event.preventDefault();
        setCurrentLogin(event.target.value)
    };

    const handleChangePassword = (event) => {
        event.preventDefault();
        setPassword(event.target.value)
    };

    return (
        <Fragment>
            <form onSubmit={handleSubmit} method="POST">
                <div className="container">
                    <div className="container sometext">
                        Авторизация
                    </div>
                    <p>Пожалуйста, заполните все поля</p>
                    <input onChange={handleChangeLogin} type="text" placeholder="Введите логин" name="login" required/>
                    <input onChange={handleChangePassword} type="password" placeholder="Введите пароль" name="psw"
                           required/>
                    <button type="submit" className="container registerbtn">Присоединиться</button>
                    <div className="container signin">
                        <p>Если у вас ещё нет аккаунта, он будет зарегистрирован с введённым логином и паролем.</p>
                    </div>
                </div>
            </form>
        </Fragment>
    )
};