import * as React from 'react';
import {Redirect, Route} from 'react-router-dom';
import {Messenger} from "../pages/Messenger";
import {useAuth} from "../../context/AuthProvider";

const MainRouter = (authed = false, ...props) => {
    const {isAuth, setIsAuth} = useAuth()
    const {component: Component, ...rest} = props;

    return (
        <Route
            {...rest}
            render={(routeProps) =>
                isAuth ? (
                    <Messenger {...routeProps}/>
                ) : (
                    <Redirect
                        to={{pathname: "/login", state: {from: routeProps.location}}}
                    />
                )
            }
        />
    );
};

export default MainRouter;