import React, {Fragment, useEffect, useRef, useState} from 'react';
import moment from 'moment';

import './style.css';
import Message from "../Message";
import {messagesApi} from "../../../utils/Api";
import {useAuth} from "../../../context/AuthProvider";
import NewMessageArea from "../NewMessageArea";

export default function MessageList(props) {
    const [messages, setMessages] = useState([])
    const {login} = useAuth()

    async function getMessages() {
        let messages = await messagesApi.list(props.currentDialog)
        setMessages(() => messages)
    }

    useEffect(() => {
        getMessages()
    }, [props.currentDialog])


    const renderMessages = () => {
        let i = 0;
        let messageCount = messages.length;
        let tempMessages = [];

        while (i < messageCount) {
            let previous = messages[i - 1];
            let current = messages[i];
            let next = messages[i + 1];
            let isMine = current.from === login;
            let currentMoment = moment(current.time);
            let prevBySameAuthor = false;
            let nextBySameAuthor = false;
            let startsSequence = true;
            let endsSequence = true;
            let showTimestamp = true;

            if (previous) {
                let previousMoment = moment(previous.time);
                let previousDuration = moment.duration(currentMoment.diff(previousMoment));
                prevBySameAuthor = previous.from === current.to;

                if (prevBySameAuthor && previousDuration.as('hours') < 1) {
                    startsSequence = false;
                }

                if (previousDuration.as('hours') < 1) {
                    showTimestamp = false;
                }
            }

            if (next) {
                let nextMoment = moment(next.time);
                let nextDuration = moment.duration(nextMoment.diff(currentMoment));
                nextBySameAuthor = next.from === current.from;

                if (nextBySameAuthor && nextDuration.as('hours') < 1) {
                    endsSequence = false;
                }
            }

            tempMessages.push(
                <Message
                    key={i}
                    isMine={isMine}
                    startsSequence={startsSequence}
                    endsSequence={endsSequence}
                    showTimestamp={showTimestamp}
                    data={current}
                />
            );

            // Proceed to the next message.
            i += 1;
        }

        return tempMessages;
    }

    if (props.currentDialog)
        return (
            <Fragment>
                <div className="message-list">
                    <h1>{props.currentDialog}</h1>
                    <div className="message-list-container">{renderMessages()}
                        <AlwaysScrollToBottom/>
                    </div>
                </div>
                <div>
                    <NewMessageArea currentDialog={props.currentDialog}
                                    getMessages={getMessages}
                    />
                </div>
            </Fragment>
        );
    else
        return (
            <h1>Нету</h1>
        )
}
const AlwaysScrollToBottom = () => {
    const elementRef = useRef();
    useEffect(() => elementRef.current.scrollIntoView());
    return <div ref={elementRef}/>;
};
