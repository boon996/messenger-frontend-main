import React, {useEffect, useState} from 'react';

import './style.css';
import DialogListItem from "../DialogItem";
import {dialogsApi} from "../../../utils/Api";
import ConversationSearch from "../ContactsSearch";

export default function DialogList(props) {
    const [dialogs, setDialogs] = useState([]);

    async function getDialogs() {
        let dialogs = await dialogsApi.list()
        setDialogs(() => dialogs)
    }

    useEffect(() => {
        getDialogs()
    }, [])

    return (
        <div className="dialog-list">
            <ConversationSearch dialogs={dialogs} setDialogs={setDialogs} currentDialog={props.currentDialog} />
            {
                dialogs.map(dialog =>
                    <DialogListItem
                        key={dialog.login}
                        data={dialog}
                        setCurrentDialog={props.setCurrentDialog}
                        currentDialog={props.currentDialog}
                    />
                )
            }
        </div>
    );
}