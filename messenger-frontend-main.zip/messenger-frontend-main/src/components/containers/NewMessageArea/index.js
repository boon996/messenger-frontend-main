import React, {useState} from "react";

import "./style.css"
import {messagesApi} from "../../../utils/Api";

export default function NewMessageArea(props) {
    const [currentMessage, setCurrentMessage] = useState("");

    function sendNewMessage(event) {
        event.preventDefault()
        const response = messagesApi.send(props.currentDialog, currentMessage)
        setCurrentMessage("")
        props.getMessages()
    }

    const handleChangeLogin = (event) => {
        event.preventDefault();
        setCurrentMessage(event.target.value)
    };

    return (
        <div >
            <form onSubmit={sendNewMessage} className="new-message-area">
                <input
                    type="text"
                    onChange={handleChangeLogin}
                    className="new-message-area-input"
                    placeholder="Введите сообщение"
                    value={currentMessage}
                />
                <button type="submit" className="sendbtn">Отправить сообщение</button>
            </form>
        </div>
    );
}