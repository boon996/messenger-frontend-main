import React, {useState, Fragment} from 'react';
import './ContactsSearch.css';
import {dialogsApi, changeToken} from "../../../utils/Api";

export default function ConversationSearch(props) {
    const [login, setLogin] = useState("");

    const handleSubmit = (event) => {
        event.preventDefault();

        const result = dialogsApi.add(login)
        const dialogs = [...props.dialogs, {"login": login, "text": null}]
        props.setDialogs(dialogs)
    };

    const handleChangeLogin = (event) => {
        event.preventDefault()
        setLogin(event.target.value)
    };

    return (
        <Fragment>
            <form onSubmit={handleSubmit} className="conversation-search">
                <input onChange={handleChangeLogin}
                       type="search"
                       className="conversation-search-input"
                       placeholder="Контакт"
                />
                <button type="submit" className="searchbtn">Добавить</button>
            </form>
        </Fragment>
    );
}