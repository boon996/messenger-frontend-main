import React from 'react';

import './style.css';

export default function DialogListItem(props) {
    const {login, lastMessage} = props.data;

    function changeCurrentDialog() {
        props.setCurrentDialog(login)
    }

    const isCurrentDialog = props.currentDialog === login
    const dialogItemClass = "dialog-list-item" + (isCurrentDialog ? " selected" : "")

    return (
        <div className={dialogItemClass} onClick={changeCurrentDialog}>
            <div className="dialog-info">
                <h1 className="dialog-title">{login}</h1>
                <p className="dialog-snippet">{lastMessage}</p>
            </div>
        </div>
    );
}