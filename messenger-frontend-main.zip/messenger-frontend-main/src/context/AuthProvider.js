import React, {useContext} from "react";
import useLocalStorage from "react-use/esm/useLocalStorage";

const AuthContext = React.createContext({});

export function AuthProvider(props) {
    const [token, setToken] = useLocalStorage("token", null)
    const [isAuth, setIsAuth] = useLocalStorage("isAuth", false)
    const [login, setLogin] = useLocalStorage("login", null)

    return <AuthContext.Provider value={{isAuth, setIsAuth, token, setToken, login, setLogin}} {...props}/>
}

export const useAuth = () => useContext(AuthContext);