import './App.css';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'
import MainRouter from './components/routers/MainRouter'
import {AuthProvider} from './context/AuthProvider'
import React from "react";
import {Login} from "./components/pages/Login";
import {Messenger} from "./components/pages/Messenger";

function App() {
    return (
        <AuthProvider>
            <Router>
                <Switch>
                    <Route exact path="/login" name="Login Page"
                           render={(props) => <Login {...props} />}/>
                    <MainRouter path="/" component={Messenger}/>
                </Switch>
            </Router>
        </AuthProvider>
    );
}

export default App;
